package android.app;

/**
 * @author weishu
 * @date 2018/8/7.
 */
public class LoadedApk {
}
