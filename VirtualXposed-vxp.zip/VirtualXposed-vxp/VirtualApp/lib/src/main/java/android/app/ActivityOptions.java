package android.app;

/**
 * @author weishu
 * @date 2021/2/24.
 */

class ActivityOptions {
}
