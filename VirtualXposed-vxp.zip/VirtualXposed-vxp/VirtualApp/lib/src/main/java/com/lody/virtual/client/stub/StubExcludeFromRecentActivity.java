package com.lody.virtual.client.stub;

/**
 * deal with Activity manifest property excludeFromRecents
 * deal with the bug : Mobile Legends has two recent task
 * added by xiawanli,  2018.9.6
 */
public abstract class StubExcludeFromRecentActivity extends StubActivity {

    public static class C0 extends StubExcludeFromRecentActivity {
    }

    public static class C1 extends StubExcludeFromRecentActivity {
    }

    public static class C2 extends StubExcludeFromRecentActivity {
    }

    public static class C3 extends StubExcludeFromRecentActivity {
    }

    public static class C4 extends StubExcludeFromRecentActivity {
    }

    public static class C5 extends StubExcludeFromRecentActivity {
    }

    public static class C6 extends StubExcludeFromRecentActivity {
    }

    public static class C7 extends StubExcludeFromRecentActivity {
    }

    public static class C8 extends StubExcludeFromRecentActivity {
    }

    public static class C9 extends StubExcludeFromRecentActivity {
    }

    public static class C10 extends StubExcludeFromRecentActivity {
    }

    public static class C11 extends StubExcludeFromRecentActivity {
    }

    public static class C12 extends StubExcludeFromRecentActivity {
    }

    public static class C13 extends StubExcludeFromRecentActivity {
    }

    public static class C14 extends StubExcludeFromRecentActivity {
    }

    public static class C15 extends StubExcludeFromRecentActivity {
    }

    public static class C16 extends StubExcludeFromRecentActivity {
    }

    public static class C17 extends StubExcludeFromRecentActivity {
    }

    public static class C18 extends StubExcludeFromRecentActivity {
    }

    public static class C19 extends StubExcludeFromRecentActivity {
    }

    public static class C20 extends StubExcludeFromRecentActivity {
    }

    public static class C21 extends StubExcludeFromRecentActivity {
    }

    public static class C22 extends StubExcludeFromRecentActivity {
    }

    public static class C23 extends StubExcludeFromRecentActivity {
    }

    public static class C24 extends StubExcludeFromRecentActivity {
    }

    public static class C25 extends StubExcludeFromRecentActivity {
    }

    public static class C26 extends StubExcludeFromRecentActivity {
    }

    public static class C27 extends StubExcludeFromRecentActivity {
    }

    public static class C28 extends StubExcludeFromRecentActivity {
    }

    public static class C29 extends StubExcludeFromRecentActivity {
    }

    public static class C30 extends StubExcludeFromRecentActivity {
    }

    public static class C31 extends StubExcludeFromRecentActivity {
    }

    public static class C32 extends StubExcludeFromRecentActivity {
    }

    public static class C33 extends StubExcludeFromRecentActivity {
    }

    public static class C34 extends StubExcludeFromRecentActivity {
    }

    public static class C35 extends StubExcludeFromRecentActivity {
    }

    public static class C36 extends StubExcludeFromRecentActivity {
    }

    public static class C37 extends StubExcludeFromRecentActivity {
    }

    public static class C38 extends StubExcludeFromRecentActivity {
    }

    public static class C39 extends StubExcludeFromRecentActivity {
    }

    public static class C40 extends StubExcludeFromRecentActivity {
    }

    public static class C41 extends StubExcludeFromRecentActivity {
    }

    public static class C42 extends StubExcludeFromRecentActivity {
    }

    public static class C43 extends StubExcludeFromRecentActivity {
    }

    public static class C44 extends StubExcludeFromRecentActivity {
    }

    public static class C45 extends StubExcludeFromRecentActivity {
    }

    public static class C46 extends StubExcludeFromRecentActivity {
    }

    public static class C47 extends StubExcludeFromRecentActivity {
    }

    public static class C48 extends StubExcludeFromRecentActivity {
    }

    public static class C49 extends StubExcludeFromRecentActivity {
    }


}
